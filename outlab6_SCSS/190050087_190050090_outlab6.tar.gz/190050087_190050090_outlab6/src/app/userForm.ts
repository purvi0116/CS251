//export class Form {
  //  name: string;
   // email: string;
   // feedback: string;
   // comment: string;
  //}

  export class Form{
    constructor(
     public name: string,
     public email: string,
     public feedback: string,
     public comment: string){}
  }